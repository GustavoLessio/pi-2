const product = [
    { id: 1, name: "Compras" },
    { id: 2, name: "Gerar Cartão" },
    { id: 3, name: "Relatório" }
];

const cart = [];

function redirecionarPagina(productId) {
    switch (productId) {
        case 1:
            // Redirecionar para a página de compra (caminho relativo)
            window.location.href = "dentrodecompras.html";
            break;
        case 2:
            // Redirecionar para a página de gerar cartão (caminho relativo)
            window.location.href = "dentrodecartao.html";
            break;
        case 3:
            // Redirecionar para a página de relatório (caminho relativo)
            window.location.href = "dentroderelatorio.html";
            break;
        default:
            break;
    }
}

// Atualizar a função addToCart para redirecionar
function addToCart(productId) {
    redirecionarPagina(productId);
}



function adicionacarro(productId) {
    const product = products.find(p => p.id === productId);
    if (product) {
        cart.push(product);
        updateCart();
        
        
    }

    }





/*oque esta abaixo é inutil por enquanto 01/10/2023*/






/*function calcularPontos(price, fatorExigencia) {    
    const pontosPorReal = 1;
    return price * pontosPorReal * fatorExigencia;
}

function atualizarPontos(fatorExigencia) {
    const totalPoints = document.getElementById("total-points");
    let pontosTotal = 0;

    cart.forEach(item => {
        pontosTotal += calcularPontos(item.price , fatorExigencia);
    });

    totalPoints.textContent = `Pontos Totais: ${pontosTotal.toFixed(2)}`;
} 


function adicionacarro(productId) {
    const product = products.find(p => p.id === productId);
    if (product) {
        cart.push(product);
        updateCart();
        
    }
}


function removeFromCart(productId) {
    const index = cart.find(item => item.id === productId);
    if (index !== -1) {
        cart.splice(index, 1); 
        updateCart();
        
    }
}


function updateCart() {
    const cartItems = document.getElementById("cart-items");
    const totalPrice = document.getElementById("total-price");

    cartItems.innerHTML = "";
    let total = 0;

    cart.forEach(item => {
        const li = document.createElement("li");
        li.className = "cart-item"; 

        const itemName = document.createElement("span");
        itemName.textContent = `${item.name} - R$ ${item.price.toFixed(2)}`;
        li.appendChild(itemName);

        const removeButton = document.createElement("button");
        removeButton.textContent = "X";
        removeButton.onclick = () => removeFromCart(item.id);
        li.appendChild(removeButton);

        cartItems.appendChild(li);
        total += item.price;
    });

    totalPrice.textContent = `Total: R$ ${total.toFixed(2)}`;
} 

*/




function confirmarCompra() {

    
    atualizarPontos(0.2);
    updateCart();
}

function esvaziarcarro(){
    cart.lenght = 0;
    updateCart();
}
